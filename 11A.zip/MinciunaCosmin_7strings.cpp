#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;

int main()
{
    char a[50];
    cout<<"a=";
    gets(a);
    for(int i=0;i<strlen(a);i++)
    switch(a[i]){
        case 'a': a[i]='c'; break;
        case 'b': a[i]='e'; break;
        case 'c': a[i]='g'; break;
        case 'd': a[i]='i'; break;
        case 'e': a[i]='k'; break;
        case 'f': a[i]='m'; break;
        case 'g': a[i]='o'; break;
        case 'h': a[i]='q'; break;
        case 'i': a[i]='s'; break;
        case 'j': a[i]='u'; break;
        case 'k': a[i]='w'; break;
        case 'l': a[i]='y'; break;}
cout<<a;
}
